def backtracking_interview(nums: list[int]) -> list[list[int]]:
    """
    INTERVIEW — All permutations of a list of unique integers.

    Return all possible orderings of the input list.
    Classic interview question — expected O(n * n!) time.

    Examples:
        [1, 2, 3]  -> [[1,2,3], [1,3,2], [2,1,3], [2,3,1], [3,1,2], [3,2,1]]
        [0, 1]     -> [[0,1], [1,0]]
        [1]        -> [[1]]
    """
    results = []
    n = len(nums)
    used = [False] * n                      # Allows you to track items already selected
    def backtrack(current):
        if len(current) == n:               # If the current permutation is complete, we add it
            results.append(list(current))
            return
        for i in range(n):                  # We try each element of the list for the current position
            if not used[i]:                 # Choice
                used[i] = True
                current.append(nums[i])
                backtrack(current)          # Exploration
                current.pop()               # Coming back (Backtrack)
                used[i] = False
    backtrack([])
    return results

result=(backtracking_interview([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]))
print(result)
print(len(result))